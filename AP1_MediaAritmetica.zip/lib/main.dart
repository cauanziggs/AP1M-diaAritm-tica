import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora de Média',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController nota1Controller = TextEditingController();
  TextEditingController nota2Controller = TextEditingController();
  TextEditingController nota3Controller = TextEditingController();

  double media = 0.0;

  String resultado = '';

  void calcularMedia() {
    double nota1 = double.tryParse(nota1Controller.text) ?? 0.0;
    double nota2 = double.tryParse(nota2Controller.text) ?? 0.0;
    double nota3 = double.tryParse(nota3Controller.text) ?? 0.0;

    setState(() {
      media = (nota1 + nota2 + nota3) / 3;

      if (media >= 7.0) {
        resultado = 'Aprovado';
      } else {
        resultado = 'Reprovado';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculadora de Média'),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                "assets/background.png"), // Coloque o caminho da imagem aqui
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                TextField(
                  controller: nota1Controller,
                  decoration: InputDecoration(
                    labelText: 'Nota 1',
                    labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
                TextField(
                  controller: nota2Controller,
                  decoration: InputDecoration(
                    labelText: 'Nota 2',
                    labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
                TextField(
                  controller: nota3Controller,
                  decoration: InputDecoration(
                    labelText: 'Nota 3',
                    labelStyle: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    calcularMedia();
                    if (media >= 7.0) {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text("Parabéns"),
                            content: Text("Você foi aprovado!"),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Text("OK"),
                              ),
                            ],
                          );
                        },
                      );
                    } else {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text("Infelizmente"),
                            content: Text("Você foi reprovado!"),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: Text("OK"),
                              ),
                            ],
                          );
                        },
                      );
                    }
                  },
                  child: Text('Calcular Média',
                      style: TextStyle(fontSize: 20, color: Color(0xff000000))),
                ),
                SizedBox(height: 20),
                Text(
                  'Média: ${media.toStringAsFixed(2)}',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
                SizedBox(height: 10),
                Text(
                  'Resultado: $resultado',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
